package uibank;

public class RestAssuredUIBase {
	
		public static String userID = ""; 
		
	

}
