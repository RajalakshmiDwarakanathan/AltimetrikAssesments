package uibank;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.response.Response;

public class UiBankRegistrationViewProfile extends RestAssuredUIBase {
	
	@Test(dependsOnMethods={"uibank.UiBankAccoutCreation.accountCreation"})//chaining with account details
	public void viewAccount() {
		
		// End point for account creation
				RestAssured.baseURI="https://uibank-api.azurewebsites.net/api/";
			
				//Initiate Request
				
				// End point for account details
				RestAssured.baseURI="https://uibank-api.azurewebsites.net/api/";

				//Initiate Request
			   Response response = (Response) RestAssured.given()
					   .header("authorization",userID) //Authorization details
					   .get("users/"+userID);// Addressing user table for account creation
					   
								
				//Print Status code
				System.err.println(response.statusCode());
				if(response.statusCode() == 200) {
					System.err.println("Response received successfully and user details received successful");
				}
					response.prettyPrint();

			}

}
