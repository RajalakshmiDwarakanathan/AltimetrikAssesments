package uibank;

import org.testng.Assert;
import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class UiBankAccoutCreation extends RestAssuredUIBase {
	
	@Test(dependsOnMethods={"uibank.UiBankAccountDetails.accountDetails"})  //chaining from account details request
	public void accountCreation() {
		
			// End point for account creation
			RestAssured.baseURI="https://uibank-api.azurewebsites.net/api/";
		
			//Initiate Request
			Response response = RestAssured.given().header("authorization", userID)//specify authorization details
							.contentType(ContentType.JSON)
					 	   .body("{\r\n"
							+ "\"accountNumber\": 1652734,\r\n"
							+ "\"balance\": 100,\r\n"
							+ "\"friendlyName\": \"AAA1\",\r\n"
							+ "\"type\": \"savings\",\r\n"
							+ "\"userId\": \"620f1e098932d4005f2a8879\"\r\n"
							+ "}")//json body post with request
							.log().all()
							.when()
							.post("accounts");	//path parameter for accounts table
			
			//get response in path variable
			JsonPath path = response.jsonPath();
			//Get id from received JSON response
			Object accountNumber = path.get("accountNumber");
			System.err.println("Response contains valid account number:"+accountNumber);
			//Print Status code
			System.err.println(response.statusCode());
			Assert.assertEquals(response.statusCode(), 200);
			//for assertion
			if(response.statusCode() == 200) {
				System.err.println("Response received successfully and account creation successful");
			}
     		response.prettyPrint();
	}

}
