package uibank;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class LoginUiBank extends RestAssuredUIBase{
	@Test
	public void login() {
		
			// End point for login
			RestAssured.baseURI="https://uibank-api.azurewebsites.net/api/";
		
			//Initiate Request
			Response response = RestAssured.given().contentType(ContentType.JSON)
					.body("{\r\n"
							+ " \"username\": \"drl.priya@gmail.com\",\r\n"
							+ " \"password\": \"Password@123\"\r\n"
							+ " }")
							.post("/users/login");	
			//get response in path variable
			JsonPath path = response.jsonPath();
		
			//Get id from received JSON response
			userID = path.get("id");
			System.err.println(userID);
			//Print Status code
			System.err.println(response.statusCode());
     		response.prettyPrint();
		
	
}
}
