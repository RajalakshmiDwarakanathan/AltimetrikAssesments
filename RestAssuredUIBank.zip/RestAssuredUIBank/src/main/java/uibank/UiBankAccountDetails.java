package uibank;

import org.testng.annotations.Test;

import io.restassured.RestAssured;
import io.restassured.http.ContentType;
import io.restassured.path.json.JsonPath;
import io.restassured.response.Response;

public class UiBankAccountDetails extends RestAssuredUIBase {
	@Test(dependsOnMethods={"uibank.LoginUiBank.login"})  //chaining from login request
	public void accountDetails(){
		
	
	// End point for account details
	RestAssured.baseURI="https://uibank-api.azurewebsites.net/api/";

	//Initiate Request
   Response response = (Response) RestAssured.given()
		   .header("authorization",userID)
		   .queryParam("filter[where][userId]", "620f1e098932d4005f2a8879")
		   .get("accounts");
	
	//{"friendlyName":"AAA1","type":"checking","userId":"620f1e098932d4005f2a8879","balance":100,"accountNumber":1652734}	
	

			
	//Print Status code
	System.err.println(response.statusCode());
	if(response.statusCode() == 200) {
		System.err.println("Response received successfully and account details received successful");
	}
		response.prettyPrint();

}
	
}
